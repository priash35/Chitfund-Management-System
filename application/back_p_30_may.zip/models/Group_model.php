<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Group_model extends CI_Model {

	public function __construct()
	{
		parent ::__construct();
	}
	
	public function get_groupmaster(){		
		$this->db->select('*');
		$this->db->from('Group_Master');
		$query= $this->db->get();
		return $query->result();

	}
	public function add_group_master($data)
	{		
		$result= $this->db->insert('Group_Master',$data);
		//$bank_id=$this->db->insert_id();
		return true;
	}
	public function update_group_master($id, $data)
	{
		$this->db->set($data);
		$this->db->where('id',$id);
		$this->db->update('Group_Master');
	}
	public function delete_group_master($id)    
	{
		$this->db->where('id', $id);
		$this->db->delete('Group_Master');
	}
	public function get_groupdata(){		
		$this->db->select('*');
		$this->db->from('Group_Defn');
		$query= $this->db->get();
		return $query->result();

	}
	public function get_single_groupdata($id){		
		$this->db->select('*');
		$this->db->from('Group_Defn');
		$this->db->where('id',$id);
		$query= $this->db->get();
		return $query->result();

	}
	public function delete_group($id)    
	{
		$this->db->where('id', $id);
		$this->db->delete('Group_Defn');
	}
	public function insert_group($data)
	{
		$result= $this->db->insert('Group_Defn',$data);
		$group_id=$this->db->insert_id();		
		return $group_id; 
	}
	public function get_group_types(){		
		$this->db->select('group_type');
		$this->db->from('Group_Master');		
		$query= $this->db->get();
		return $query->result();

	}
	public function update_group($id, $data)
	{
		$this->db->set($data);
		$this->db->where('id',$id);
		$this->db->update('Group_Defn');
	}

}


?>