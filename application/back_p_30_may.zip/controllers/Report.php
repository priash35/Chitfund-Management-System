<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
		
	public function __construct()
	{
		//parent::Controller();
		parent::__construct();
		/*if (!isset($_SESSION['user_logged'])) {
			
			$this->session->set_flashdata("error", "please login first view of page");
			redirect("login/index","refresh");
		}*/
		$this->load->library('form_validation');
		$this->load->library('parser');
		$this->load->model('Admin_model');	
		//$this->load->model('Company_model');		
	}	
	
	public function parse_sample()
	{
		$data = array(
        'byelaw_date' => '29/5/2018',
        'chit_amount' => '50000',
        'group_type' => 'DAILY',
        'group_name' => 'D-03',
        'duration' => '400',
        'sub' => '250'
		);

		$this->parser->parse('templates/blog_template', $data);
		
	}
	
	
	
}

?>