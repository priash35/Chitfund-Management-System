<?php include_once "master/header.php"; ?> 

<div class="wrapper">
            <div class="container-fluid">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="btn-group pull-right">
                                <ol class="breadcrumb hide-phone p-0 m-0">
                                    <li class="breadcrumb-item"><a href="#">Main</a></li>
                                    <li class="breadcrumb-item"><a href="#">Master</a></li>
                                    <li class="breadcrumb-item active">Staff Master</li>
                                </ol>
                            </div>
                            <!-- <h4 class="page-title">Tabs</h4> -->
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

				
				<div class="col-md-12">
                        <div class="card-box">
							<h3 class="header-title m-t-0 m-b-30 text-center">Add New Staff Information</h3><br>
							<div class="row">
								<div class="col-md-2">
								
								</div>
								
								<div class="col-md-8">								
									<form name="myform" id="myform" action="<?php echo base_url()?>Admin/add_staff_data" method="post" enctype="multipart/form-data">
										<div class="form-group row">
											<label class="col-3 col-form-label">First Name</label>
											<div class="col-8">
												<input id="f_name" name="f_name" type="text" class="form-control" value="" required>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Middle Name</label>
											<div class="col-8">
												<input id="m_name" name="m_name" type="text" class="form-control" value="" >
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Last Name</label>
											<div class="col-8">
												<input id="l_name" name="l_name" type="text" class="form-control" value="" required>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Designation</label>
											<div class="col-8">
												<input id="desig" name="desig" type="text" class="form-control" value="" required>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Address</label>
											<div class="col-8">
												<input id="address" name="address" class="form-control" type="text" required>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Joining Date</label>
											<div class="col-8">
												<!--<input id="j_date" name="j_date" class="form-control" type="date" required>-->
												<div class="input-group">
                                                    <input type="text" class="form-control" placeholder="yyyy/mm/dd" id="datepicker-autoclose" name="j_date">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                                    </div>
                                                   </div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Contact details:</label>
															
											<div class="col-9 row">
												<label class="col-3 col-form-label">Landline</label>
												<div class="col-8">
													<input id="landline" name="landline" type="text" class="form-control" value="" >
												</div>
											<br><br>
												<label class="col-3 col-form-label">Mobile</label>
												<div class="col-8">
													<input id="mobile" name="mobile" type="text" class="form-control" value="" >
												</div>
											<br><br>
											</div>												
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Reference</label>
											<div class="col-8">
												<input id="ref" name="ref" type="text" class="form-control" value="" >
											</div>
										</div>										
										<div class="form-group row">
											<label class="col-3 col-form-label">Documents:</label>
															
											<div class="col-9 row">
												<label class="col-3 col-form-label">ID proof</label>
												<div class="col-8">
													<input id="id_proof" name="id_proof" type="file" class="filestyle"  data-btnClass="btn-maroon">				
												</div>
											<br><br>
												<label class="col-3 col-form-label">Address proof</label>
												<div class="col-8">
													<input id="adr_proof" name="adr_proof" type="file" class="filestyle"  data-btnClass="btn-maroon">
												</div>
											<br><br>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">User ID</label>
											<div class="col-8">
												<input id="userid" name="userid" type="text" class="form-control" value="" >
											</div>
										</div>
										<div class="form-group row">
											<label class="col-3 col-form-label">Password</label>
											<div class="col-8">
												<input id="password" name="password" type="password" class="form-control" value="" >
											</div>
										</div>											
										<div class="form-group row">
											<label class="col-3 col-form-label">Role</label>
											<div class="col-8">
												<select id="role" name="role" class="form-control">
													<option value="0">Select Role</option>
													<option value="1">Admin</option>
													<option value="2">Accountant</option>
												</select>
											</div>
										</div>					
										
										<div class="col-md-12 text-center">	
												<button type="submit" id="add_staff" name="add_staff" class="btn btn-maroon btn-lg">Submit</button>
										</div>										
									</form>	
							</div>  

							<div class="col-md-2">	
							
							</div>
							
						</div>
                        </div> <!-- card block end --> 
                    </div> <!-- end col -->
					
					
               
            </div><!-- end container -->
        </div><!-- end wrapper -->
		
				
<?php include_once "master/footer.php";  ?>

