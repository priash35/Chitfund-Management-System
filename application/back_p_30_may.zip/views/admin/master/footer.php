<!-- Footer -->
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        2018 © Highdmin. - Coderthemes.com
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer -->

		
        <!-- jQuery  -->
		
        <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/plugin.js"></script>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

		<script src="<?php echo base_url();?>assets/js/form-validation.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/waves.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/modernizr.min.js"></script>
				
        <!-- App js -->
        <script src="<?php echo base_url(); ?>assets/js/jquery.core.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.app.js"></script>
		
		
		 
		<script src="<?php echo base_url(); ?>plugins/switchery/switchery.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-tagsinput/js/bootstrap-tagsinput.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/select2/js/select2.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-select/js/bootstrap-select.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-maxlength/bootstrap-maxlength.js" type="text/javascript"></script>

        <script type="text/javascript" src="<?php echo base_url(); ?>plugins/autocomplete/jquery.mockjax.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>plugins/autocomplete/jquery.autocomplete.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>plugins/autocomplete/countries.js"></script>
        <!--<script type="text/javascript" src="<?php echo base_url(); ?>assets/pages/jquery.autocomplete.init.js"></script>-->

        <!-- Init Js file -->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/pages/jquery.form-advanced.init.js"></script>
		<!--Morris Chart
        <script src="<?php //echo base_url(); ?>plugins/morris/morris.min.js"></script>
        <script src="<?php //echo base_url(); ?>plugins/raphael/raphael-min.js"></script>
        <script src="<?php //echo base_url(); ?>assets/pages/jquery.morris.init.js"></script>-->

		<!-- plugin js -->
        <script src="<?php echo base_url(); ?>plugins/moment/moment.js"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-timepicker/bootstrap-timepicker.js"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/clockpicker/js/bootstrap-clockpicker.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
        <script src="<?php echo base_url(); ?>plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

        <!-- Init js -->
        <script src="<?php echo base_url(); ?>assets/pages/jquery.form-pickers.init.js"></script>

        <!--FooTable-->
        <script src="<?php echo base_url(); ?>plugins/footable/js/footable.all.min.js"></script>
        <!--FooTable Example-->
        <script src="<?php echo base_url(); ?>assets/pages/jquery.footable.js"></script>

		<!-- Required datatable js -->
        <script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/jszip.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/pdfmake.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/vfs_fonts.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/buttons.html5.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/buttons.print.min.js"></script>

        <!-- Key Tables -->
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.keyTable.min.js"></script>

        <!-- Responsive examples -->
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/datatables/responsive.bootstrap4.min.js"></script>

        <!-- Selection table -->
        <script src="<?php echo base_url(); ?>plugins/datatables/dataTables.select.min.js"></script>

		 <!-- KNOB JS -->
        <!--[if IE]>
        <script type="text/javascript" src="../plugins/jquery-knob/excanvas.js"></script>
        <![endif]-->
        <script src="<?php echo base_url(); ?>plugins/jquery-knob/jquery.knob.js"></script>

        <!-- Counter Up  -->
        <script src="<?php echo base_url(); ?>plugins/waypoints/lib/jquery.waypoints.min.js"></script>
        <script src="<?php echo base_url(); ?>plugins/counterup/jquery.counterup.min.js"></script>
		
		

          <!-- Sweet Alert Js  -->
        <script src="<?php echo base_url(); ?>plugins/sweet-alert/sweetalert2.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/pages/jquery.sweet-alert.init.js"></script>
		
